	/* 
	 * This program is written to experiment with the use of 'print' and 'println' methods, variable declarations,
	 * string concatenation dividing integers and dividing real numbers or mixed operands.
	 * 
	 * CSC 1350 Programming Project no.2
	 * Section [2]
	 * @author Martin Dampier
	 * @since 9/9/19
	 */
public class Prog01_ExploringJava {
	
public static void main(String[]args)
{
	//step7, 8, 9, 10
	int first = 3, second = 8;
	
	//step2
    System.out.println("first name: John"); //need '(',')', and the double quotes
    System.out.println(" last name: Tyler");   //the leading space aligns the ":"s
    
    //step6 part 1
    System.out.println();
    
    //step4
    System.out.println("first name: John");
    System.out.println(" last name: Tyler");
    
    //step6 part 2
    System.out.println();
    System.out.println("first name: John");
    System.out.println(" last name: Tyler");
    
    //step11
    System.out.println();
    System.out.println("first = " + first + ", second = " + second);
    
    //step15
    double average = (first + second)/2.0;
    System.out.println();
    System.out.println("Average = " + average);
    
    //step16
    int quotient = second / first;
    int remainder = second % first;
    System.out.println();
    System.out.println("Quotient of second/first = " + quotient);
    System.out.println("Remainder of second/first = " + remainder);
    
    //step17
    System.out.println();
    String firstname = "John";
    System.out.println("first name: " + firstname);
    
    //step19
    String name = "John Tyler";
    System.out.println();
    System.out.println("name: " + name);
}
}
